# Приёмочные тест-кейсы

Ссылка на проект: [https://app.qase.io/project/COURSEWORK](https://app.qase.io/project/COURSEWORK)

Логин: houseindahouse@mail.ru

Пароль: testuser2023